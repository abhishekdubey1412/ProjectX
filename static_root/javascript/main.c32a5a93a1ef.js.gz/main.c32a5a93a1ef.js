var message_timeout = document.getElementById("message_alert");

setTimeout(function () {
    message_timeout.style.setProperty("display", "none", "important");
}, 5000);